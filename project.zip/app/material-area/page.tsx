'use client';

export default function MaterialPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Halaman Material</h1>
      <p>Sedang dalam pengembangan atau silakan pindahkan kode dari material-area ke sini.</p>
    </div>
  );
}