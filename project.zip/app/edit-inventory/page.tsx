import { redirect } from "next/navigation";

export default function EditInventoryPage() {
  redirect("/admin/edit-inventory");
}