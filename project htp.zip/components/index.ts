import { InventoryTable } from "@/components/inventory-table";

// Ekspor InventoryTable agar bisa digunakan di halaman inventory
export { InventoryTable };