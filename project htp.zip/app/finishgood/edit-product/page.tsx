import { redirect } from "next/navigation";

export default function EditProductPage() {
  redirect("/finishgood/admin/edit-product");
}